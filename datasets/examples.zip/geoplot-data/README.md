# geoplot-data

This repository archives the raw data files used by the geoplot examples and documentation. Zip this up and stick it in `geoplot/datasets` as `examples.zip`.
